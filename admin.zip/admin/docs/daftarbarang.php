<div class="halaman">
    <div class="container mt-4">
        <?php include('assets/message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Detail Barang
                            <a href="./login/tambahbarang.php" class="btn btn-primary float-end">Tambah Barang</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Kode Barang</th>
                                    <th>Nama Barang</th>
                                    <th>Jenis Barang</th>
                                    <th>Satuan Barang</th>
                                    <th>Harga Beli</th>
                                    <th>Harga Grosir</th>
                                    <th>Harga Jual</th>
                                    <th>Spek Minimu</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM daftarbarang";
                                $query_run = mysqli_query($koneksi, $query);

                                if (mysqli_num_rows($query_run) > 0) {
                                    foreach ($query_run as $daftarbarang) {
                                ?>
                                        <tr>
                                            <td>
                                                <?php echo $daftarbarang['kodebarang']; ?>
                                            </td>
                                            <td>
                                                <?php echo $daftarbarang['namabarang']; ?>
                                            </td>
                                            <td>
                                                <?php echo $daftarbarang['jenisbarang']; ?>
                                            </td>
                                            <td>
                                                <?php echo $daftarbarang['satuanbarang']; ?>
                                            </td>
                                            <td>
                                                Rp.<?php echo $daftarbarang['hargabeli']; ?>
                                            </td>
                                            <td>
                                                Rp.<?php echo $daftarbarang['hargagrosir']; ?>
                                            </td>
                                            <td>
                                                Rp.<?php echo $daftarbarang['hargajual']; ?>
                                            </td>
                                            <td>
                                                <?php echo $daftarbarang['spekminimum']; ?>
                                            </td>
                                            <td>
                                                <a href="docs/assets/edit.php?id=<?php echo $daftarbarang['id']; ?>" class="btn btn-success btn-sm d-inline">Edit</a>
                                                <form action="" method="post" class="d-inline">
                                                    <button type="submit" name="hapusdaftarbarang" value="<?php echo $daftarbarang['id']; ?>" class="btn btn-danger btn-sm">Hapus</button>
                                                </form>
                                            </td>
                                        </tr>
                                <?php
                                    }
                                } else {
                                    echo "<h5> No Record Found </h5>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>