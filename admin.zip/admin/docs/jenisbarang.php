
<div class="halaman">
    <div class="container mt-4">
        <?php include('assets/message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Detail Jenis Barang
                            <a href="student-create.php" class="btn btn-primary float-end">Tambah Jenis Barang</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nama Barang</th>
                                    <th>Jenis Barang</th>
                                    <th>Satuan Barang</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $query = "SELECT * FROM jenisbarang";
                                    $query_run = mysqli_query($koneksi, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $jenisbarang)
                                        {
                                    ?>
                                    <tr>
                                        <td><?php echo $jenisbarang['id']; ?></td>
                                        <td><?php echo $jenisbarang['namabarang']; ?></td>
                                        <td><?php echo $jenisbarang['jenisbarang']; ?></td>
                                        <td><?php echo $jenisbarang['satuanbarang']; ?></td>
                                        <td>
                                        <a href="./login/editstok.php<?php echo $jenisbarang['id']; ?>" class="btn btn-success btn-sm ml-5">Edit</a>
                                        <form action="" method="post" class="d-inline">
                                            <button type="submit" name="hapus" value="<?php echo $jenisbarang['id'];?>" class="btn btn-danger btn-sm">Hapus</button>
                                        </form>
                                        </td>
                                    </tr>
                                    <?php
                                    }
                                }
                                else
                                {
                                    echo "<h5> No Record Found </h5>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>