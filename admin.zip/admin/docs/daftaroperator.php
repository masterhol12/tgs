
<div class="halaman">
    <div class="container mt-4">
        <?php include('assets/message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Detail Operator
                            <a href="student-create.php" class="btn btn-primary float-end">Tambah Operator</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nama Operator</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $query = "SELECT * FROM daftaroperator";
                                    $query_run = mysqli_query($koneksi, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $daftaroperator)
                                        {
                                    ?>
                                    <tr>
                                        <td><?php echo $daftaroperator['id']; ?></td>
                                        <td><?php echo $daftaroperator['namaoperator']; ?></td>
                                        <td>
                                        <a href="docs/assets/edit.php?id=<?php echo $daftaroperator['id']; ?>" class="btn btn-success btn-sm ml-5">Edit</a>
                                        <form action="code.php" method="POST" class="d-inline">
                                            <button type="submit" name="hapusoperator" value="<?php echo $daftaroperator['id'];?>" class="btn btn-danger btn-sm">Hapus</button>
                                        </form>
                                        </td>
                                    </tr>
                                    <?php
                                    }
                                }
                                else
                                {
                                    echo "<h5> No Record Found </h5>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>