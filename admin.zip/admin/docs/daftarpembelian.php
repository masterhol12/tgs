
<div class="halaman">
    <div class="container mt-4">
        <?php include('assets/message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Detail Pembelian
                            <a href="student-create.php" class="btn btn-primary float-end">Tambah Pembelian</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Barang</th>
                                    <th>Harga</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $query = "SELECT * FROM daftarpembelian";
                                    $query_run = mysqli_query($koneksi, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $daftarpembelian)
                                        {
                                    ?>
                                    <tr>
                                        <td><?php echo $daftarpembelian['id']; ?></td>
                                        <td><?php echo $daftarpembelian['barang']; ?></td>
                                        <td>Rp.<?php echo $daftarpembelian['harga']; ?></td>
                                        <td>
                                        <a href="docs/assets/edit.php?id=<?php echo $daftarpembelian['id']; ?>" class="btn btn-success btn-sm ml-5">Edit</a>
                                        <form action="code.php" method="POST" class="d-inline">
                                            <button type="submit" name="delete_student" value="<?php echo $daftarpembelian['id'];?>" class="btn btn-danger btn-sm">Hapus</button>
                                        </form>
                                        </td>
                                    </tr>
                                    <?php
                                    }
                                }
                                else
                                {
                                    echo "<h5> No Record Found </h5>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>