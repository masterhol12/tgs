<div class="halaman">
    <div class="container mt-4">
        <?php include('assets/message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Detail Costumer
                            <a href="./login/tambahcostumer.php" class="btn btn-primary float-end">Tambah Costumer</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nama Costumer</th>
                                    <th>Alamat</th>
                                    <th>Telepon</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM daftarcostumer";
                                $query_run = mysqli_query($koneksi, $query);

                                if (mysqli_num_rows($query_run) > 0) {
                                    foreach ($query_run as $daftarcostumer) {
                                ?>
                                        <tr>
                                            <td><?php echo $daftarcostumer['id']; ?></td>
                                            <td><?php echo $daftarcostumer['namacostumer']; ?></td>
                                            <td><?php echo $daftarcostumer['alamat']; ?></td>
                                            <td><?php echo $daftarcostumer['telepon']; ?></td>
                                            <td>
                                                <a href="docs/assets/edit.php?id=<?php echo $daftarcostumer['id']; ?>" class="btn btn-success btn-sm ml-5">Edit</a>
                                                <form action="" method="POST" class="d-inline">
                                                    <button type="submit" name="hapusdaftarcostumer" value="<?php echo $daftarcostumer['id']; ?>" class="btn btn-danger btn-sm">Hapus</button>
                                                </form>
                                            </td>
                                        </tr>
                                <?php
                                    }
                                } else {
                                    echo "<h5> No Record Found </h5>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>