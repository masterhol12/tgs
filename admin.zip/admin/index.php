<?php
session_start();
include 'login/koneksi.php';
include 'login/hapus.php';


if (!isset($_SESSION['login'])) {
  header('location: ./login/login.php');
  exit;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin | Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
  <!-- boostrap icon -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
      <!-- Left navbar links -->
      <li class="nav-item d-none d-sm-inline-block">
        <a class="nav-link text-body" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>

      <!-- Right navbar links -->
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" data-widget="fullscreen" href="#" role="button">
            <i class="fas fa-expand-arrows-alt"></i>
          </a>
        </li>
        </li>
      </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary">
      <!-- Brand Logo -->
      <a href="index.php?page=home" class="brand-link nav-link">
        <span class="brand-text font-weight-light ml-5">Admin Menu</span>
      </a>

      <!-- Sidebar -->
      <div class="sidebar">

        <!-- Sidebar Menu -->
        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="nav-icon bi bi-mastodon"></i>
                <p>
                  Master
                  <i class="right fas fa-angle-left"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <!-- <li class="nav-item">
                <a href="index.php?page=jenisbarang" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Daftar Jenis Barang</p>
                </a>
              </li> -->
                <li class="nav-item">
                  <a href="index.php?page=daftarsuplayer" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Daftar Suplayer</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="index.php?page=daftarcostumer" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Daftar Costumer</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="index.php?page=daftarbarang" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Daftar Barang</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="index.php?page=daftaroperator" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Daftar Operator</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="index.php?page=pengisianbarcode" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Pengisian Barcode</p>
                  </a>
                </li>
              </ul>
            </li>
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="nav-icon bi bi-cart3"></i>
                <p>
                  Transaksi
                  <i class="right fas fa-angle-left"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="index.php?page=pembelian" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Pembelian</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="index.php?page=penjualan" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Penjualan</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="index.php?page=daftarpenjualan" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Daftar Penjualan</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="index.php?page=daftarpembelian" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Daftar Pembelian</p>
                  </a>
                </li>
              </ul>
            </li>
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="nav-icon bi bi-bag-check-fill"></i>
                <p>
                  Stok
                  <i class="right fas fa-angle-left"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="index.php?page=tambahkurangstok" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Tambah / Kurang Stok</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="index.php?page=laporanstok" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Laporan Stok</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="index.php?page=kartustok" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Kartu Stok</p>
                  </a>
                </li>
              </ul>
            </li>
            <li class="nav-item">
              <a href="index.php?page=mail" class="nav-link">
                <i class="nav-icon bi bi-envelope-at-fill"></i>
                <p>
                  Mailbox
                  <span class="badge badge-info right">999+</span>
                </p>
              </a>
            </li>
            <li class="nav-item">
              <a href="index.php?page=laporan" class="nav-link">
                <i class="nav-icon bi bi-envelope-exclamation"></i>
                <p>
                  Laporan
                </p>
              </a>
            </li>
            <li class="nav-item">
              <a href="login/logout.php" class="nav-link">
                <i class="nav-icon bi bi-box-arrow-left"></i>
                <p>
                  Logout
                </p>
              </a>
            </li>
            <li class="nav-item">
              <a href="login/register.php" class="nav-link">
                <i class="nav-icon bi bi-person-plus-fill"></i>
                <p>
                  Register
                </p>
              </a>
            </li>
          </ul>
        </nav>
        <!-- /.sidebar-menu -->
      </div>
      <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Dashboard</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="index.php?page=home">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">

        <div class="container-fluid">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="col-lg-3 col-6">
              <!-- small box -->
              <div class="small-box bg-info">
                <div class="inner">
                  <h3>150</h3>

                  <p>New Orders</p>
                </div>
                <div class="icon">
                  <i class="ion ion-bag"></i>
                </div>
                <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
              </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
              <!-- small box -->
              <div class="small-box bg-success">
                <div class="inner">
                  <h3>53<sup style="font-size: 20px">%</sup></h3>

                  <p>Bounce Rate</p>
                </div>
                <div class="icon">
                  <i class="ion ion-stats-bars"></i>
                </div>
                <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
              </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
              <!-- small box -->
              <div class="small-box bg-warning">
                <div class="inner">
                  <h3>44</h3>

                  <p>User Registrations</p>
                </div>
                <div class="icon">
                  <i class="ion ion-person-add"></i>
                </div>
                <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
              </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
              <!-- small box -->
              <div class="small-box bg-danger">
                <div class="inner">
                  <h3>65</h3>

                  <p>Unique Visitors</p>
                </div>
                <div class="icon">
                  <i class="ion ion-pie-graph"></i>
                </div>
                <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
              </div>
            </div>
          </div>
          <!-- /.direct-chat-pane -->
        </div>
        <!-- /.card-body -->

        <div class="content">

          <?php
          if (isset($_GET['page'])) {
            $page = $_GET['page'];

            switch ($page) {
                // home
              case 'home':
                include "docs/home.php";
                break;
                // master
              case 'jenisbarang':
                include "docs/jenisbarang.php";
                break;
              case 'daftarsuplayer':
                include "docs/daftarsuplayer.php";
                break;
              case 'daftarcostumer':
                include "docs/daftarcostumer.php";
                break;
              case 'daftarbarang':
                include "docs/daftarbarang.php";
                break;
              case 'daftaroperator':
                include "docs/daftaroperator.php";
                break;
              case 'pengisianbarcode':
                include "docs/pengisianbarcode.php";
                break;
                // transaksi
              case 'pembelian':
                include "docs/pembelian.php";
                break;
              case 'penjualan':
                include "docs/penjualan.php";
                break;
              case 'daftarpenjualan':
                include "docs/daftarpenjualan.php";
                break;
              case 'daftarpembelian':
                include "docs/daftarpembelian.php";
                break;
                // stok
              case 'tambahkurangstok':
                include "docs/tambahkurangstok.php";
                break;
              case 'laporanstok':
                include "docs/laporanstok.php";
                break;
              case 'kartustok':
                include "docs/kartustok.php";
                break;
                // mail   
              case 'mail':
                include "docs/mail.php";
                break;
                // laporan
              case 'laporan':
                include "docs/laporan.php";
                break;
                // default 
              default:
                include "docs/404.php";
                break;
            }
          } else {
            include "docs/home.php";
          }
          ?>

        </div>
      </section>
      <!-- /.content -->
    </div>

  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="plugins/jquery-ui/jquery-ui.min.js"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->

  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- ChartJS -->
  <script src="plugins/chart.js/Chart.min.js"></script>
  <!-- Sparkline -->
  <script src="plugins/sparklines/sparkline.js"></script>
  <!-- JQVMap -->
  <script src="plugins/jqvmap/jquery.vmap.min.js"></script>
  <script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
  <!-- jQuery Knob Chart -->
  <script src="plugins/jquery-knob/jquery.knob.min.js"></script>
  <!-- daterangepicker -->
  <script src="plugins/moment/moment.min.js"></script>
  <script src="plugins/daterangepicker/daterangepicker.js"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
  <!-- Summernote -->
  <script src="plugins/summernote/summernote-bs4.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>