<?php
session_start();

include 'koneksi.php';

if (isset($_SESSION['login'])) {
    header('location: ../index.php');
    exit;
}


$err        = "";
$username   = "";

if (isset($_POST["login"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $jabatan  = $_POST["jabatan"];

    $result = mysqli_query($koneksi, "SELECT * FROM login WHERE username = '$username' AND password = md5('$password')");

    $cek = mysqli_num_rows($result);

    if ($cek == 1) {
        $_SESSION['userweb'] = $username;
        $_SESSION['login'] = true;
        header("location: ../index.php");
        exit;
    } else {
        $err .= "<td>Username atau Password yang anda masukkan tidak sesuai</td>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>

<body>
    <div class="container">
        <div style="margin-top:60px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-4">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="panel-title">
                        <h1 style="font-family: bold; font-weight: bold;">Login</h1>
                    </div>

                </div>
                <div style="padding-top:30px" class="panel-body">

                    <?php if ($err) { ?>
                        <div id="login-alert" class="alert alert-danger col-sm-12">
                            <table>
                                <tr><?php echo $err ?></tr>
                            </table>
                        </div>
                    <?php } ?>

                    <form id="loginform" class="form-horizontal" action="" method="post" role="form">
                        <div style="margin-bottom: 25px" class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                            <input id="login-username" type="text" class="form-control" name="username" placeholder="Username">
                        </div>
                        <div style="margin-bottom: 25px" class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                            <input id="login-password" type="password" class="form-control" name="password" placeholder="Password">
                        </div>
                        <div style="margin-bottom: 25px" class="input-group">
                            <span class="input-group-addon"><i class="bi bi-award-fill"></i></span>
                            <input id="login-jabatan" type="text" class="form-control" name="jabatan" placeholder="Jabatan">
                        </div>
                        <div style="margin-top:10px" class="form-group">
                            <div class="col-sm-12 controls">
                                <input type="submit" name="login" class="btn btn-success" value="Login">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>