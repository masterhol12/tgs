<?php

include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $jabatan  = $_POST['jabatan'];
    $encrypted_password = md5($password);

    $query = "INSERT INTO login (username, password, jabatat) VALUES ('$username', '$encrypted_password', '$jabatan')";
    $koneksi->query($query);

    $koneksi->close();

    header('Location: login.php');
    echo "<script>alert('Data berhasil di submit');</script>";
    exit;
}

?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>registrasi menu</title>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
  </head>
  <body>
    <div class="container">    
    <div style="margin-top:60px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-4">                    
        <div class="panel panel-info" >
            <div class="panel-heading">
                <div class="panel-title"><h1 style="font-family: bold; font-weight: bold;">Register</h1></div>
            </div>
                <form id="loginform" class="form-horizontal" action="" method="post" role="form">       
                    <div style="margin-bottom: 25px" class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input id="login-username" type="text" class="form-control" name="username" placeholder="Username">                                        
                    </div>
                    <div style="margin-bottom: 25px" class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                        <input id="login-password" type="password" class="form-control" name="password" placeholder="Password">
                    </div>
                    <div style="margin-bottom: 25px" class="input-group">
                        <span class="input-group-addon"><i class="bi bi-award-fill"></i></span>
                        <input id="login-jabatan" type="text" class="form-control" name="jabatan" placeholder="Jabatan">
                    </div>
                    <div style="margin-top:10px" class="form-group">
                        <div class="col-sm-12 controls">
                            <input type="submit" name="submit" class="btn btn-success" value="Register">
                        </div>
                    </div>
                </form>    
            </div>                     
        </div>  
    </div>
</div>
  </body>
</html>
