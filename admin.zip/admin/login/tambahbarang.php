<?php

include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kodebarang = $_POST['kodebarang'];
    $namabarang = $_POST['namabarang'];
    $jenisbarang = $_POST['jenisbarang'];
    $satuanbarang = $_POST['satuanbarang'];
    $hargabeli = $_POST['hargabeli'];
    $hargagrosir = $_POST['hargagrosir'];
    $hargajual = $_POST['hargajual'];
    $spekminimum = $_POST['spekminimum'];

    $query = "INSERT INTO daftarbarang (kodebarang, namabarang, jenisbarang, satuanbarang, hargabeli, hargagrosir, hargajual, spekminimum) VALUES ('$kodebarang', '$namabarang', '$jenisbarang', '$satuanbarang', '$hargabeli', '$hargagrosir', '$hargajual', '$spekminimum' );";
    $koneksi->query($query);

    $koneksi->close();

    header('Location: ../index.php?page=daftarbarang');
    echo "<script>alert('Data berhasil di submit');</script>";
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Stok</title>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
</head>

<body>
    <div class="container">
        <div style="margin-top:60px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-4">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="panel-title">
                        <h1>Tambah Barang</h1>
                    </div>
                </div>
                <div style="padding-top:30px" class="panel-body">
                    <?php
                    $query = "SELECT * FROM daftarbarang";
                    $query_run = mysqli_query($koneksi, $query);

                    if (mysqli_num_rows($query_run) > 0) {
                        foreach ($query_run as $daftarbarang) {
                    ?>

                            <form id="loginform" class="form-horizontal" action="" method="post" role="form">
                                <div style="margin-bottom: 25px" class="input-group col-sm-12">
                                    <label class="text-center">Kode Barang</label>
                                    <input class="form-control" type="text" name="kodebarang" aria-label="Disabled input example" value="<?php echo $daftarbarang['kodebarang']; ?>">
                                </div>
                                <div style="margin-bottom: 25px" class="input-group col-sm-12">
                                    <label class="text-center">Nama Barang</label>
                                    <input class="form-control" type="text" name="namabarang" aria-label="Disabled input example">
                                </div>
                                <div style="margin-bottom: 25px" class="input-group col-sm-12">
                                    <label class="text-center">JenisBarang</label>
                                    <input class="form-control" type="text" name="jenisbarang" aria-label="Disabled input example">
                                </div>
                                <div style="margin-bottom: 25px" class="input-group col-sm-12">
                                    <label class="text-center">Satuan Barang</label>
                                    <input class="form-control" type="text" name="satuanbarang" aria-label="Disabled input example">
                                </div>
                                <div style="margin-bottom: 25px" class="input-group col-sm-12">
                                    <label class="text-center">Harga Beli</label>
                                    <input class="form-control" type="text" name="hargabeli" aria-label="Disabled input example">
                                </div>
                                <div style="margin-bottom: 25px" class="input-group col-sm-12">
                                    <label class="text-center">Harga Grosir</label>
                                    <input class="form-control" type="text" name="hargagrosir" aria-label="Disabled input example">
                                </div>
                                <div style="margin-bottom: 25px" class="input-group col-sm-12">
                                    <label class="text-center">Harga Jual</label>
                                    <input class="form-control" type="text" name="hargajual" aria-label="Disabled input example">
                                </div>
                                <div style="margin-bottom: 25px" class="input-group col-sm-12">
                                    <label class="text-center">Spek Minimum</label>
                                    <input class="form-control" type="text" name="spekminimum" aria-label="Disabled input example">
                                </div>
                                <div style="margin-top:10px" class="form-group">
                                    <div class="col-sm-12 controls">
                                        <input type="submit" name="submit" class="btn btn-primary" value="Submit">
                                    </div>
                                </div>
                            </form>
                    <?php
                        }
                    } else {
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</body>

</html>