<?php

if (isset($_POST['hapusstokbarang'])) {
  $stokbarang_id = mysqli_real_escape_string($koneksi, $_POST['hapusstokbarang']);

  $query = "DELETE FROM stokbarang WHERE id='$stokbarang_id' ";
  $query_run = mysqli_query($koneksi, $query);

  if ($query_run) {
    $_SESSION['message'] = "Berhasil Menghapus Stokbarang";
    header("Refresh: 0; url=index.php?page=tambahkurangstok");
    exit();
  } else {
    $_SESSION['message'] = "Gagal Menghapus Stokbarang";
    header("Refresh: 0; url=index.php?page=tambahkurangstok");
    exit();
  }
} elseif (isset($_POST['hapusdaftarbarang'])) {
  $daftarbarang_id = mysqli_real_escape_string($koneksi, $_POST['hapusdaftarbarang']);

  $query = "DELETE FROM daftarbarang WHERE id='$daftarbarang_id' ";
  $query_run = mysqli_query($koneksi, $query);

  if ($query_run) {
    $_SESSION['message'] = "Berhasil Menghapus Stokbarang";
    header("Refresh: 0; url=index.php?page=daftarbarang");
    exit();
  } else {
    $_SESSION['message'] = "Gagal Menghapus Stokbarang";
    header("Refresh: 0; url=index.php?page=daftarbarang");
    exit();
  }
} elseif (isset($_POST['hapusdaftarcostumer'])) {
  $daftarcostumer_id = mysqli_real_escape_string($koneksi, $_POST['hapusdaftarcostumer']);

  $query = "DELETE FROM daftarcostumer WHERE id='$daftarcostumer_id' ";
  $query_run = mysqli_query($koneksi, $query);

  if ($query_run) {
    $_SESSION['message'] = "Berhasil Menghapus daftarcostumer";
    header("Refresh: 0; url=index.php?page=daftarcostumer");
    exit();
  } else {
    $_SESSION['message'] = "Gagal Menghapus daftarcostumer";
    header("Refresh: 0; url=index.php?page=daftarcostumer");
    exit();
  }
} elseif (isset($_POST['hapusoperator'])) {
  $daftaroperator_id = mysqli_real_escape_string($koneksi, $_POST['hapusoperator']);

  $query = "DELETE FROM daftaroperator WHERE id='$daftaroperator_id' ";
  $query_run = mysqli_query($koneksi, $query);

  if ($query_run) {
    $_SESSION['message'] = "Berhasil Menghapus daftaroperator";
    header("Refresh: 0; url=index.php?page=daftaroperator");
    exit();
  } else {
    $_SESSION['message'] = "Gagal Menghapus daftaroperator";
    header("Refresh: 0; url=index.php?page=daftaroperator");
    exit();
  }
}
