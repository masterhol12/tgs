<?php  

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'login';

$koneksi = mysqli_connect($host, $user, $password, $database);

if (!$koneksi) {
    die("Gagal terkoneksi: " . mysqli_connect_error());
}
echo "<script>
	console.log('Koneksi Berhasil');
	</script>";

?>