<?php

include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tambahstok = $_POST['tambahstok'];

    $query = "INSERT INTO stokbarang (stokbarang) VALUES ('$tambahstok')";
    $koneksi->query($query);

    $koneksi->close();

    header('Location: ../index.php?page=tambahkurangstok');
    echo "<script>alert('Data berhasil di submit');</script>";
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Stok</title>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
</head>

<body>
    <div class="container">
        <div style="margin-top:60px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-4">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="panel-title">
                        <h1>Tambah Stok</h1>
                    </div>
                </div>
                <div style="padding-top:30px" class="panel-body">


                    <form id="loginform" class="form-horizontal" action="" method="post" role="form">
                        <div style="margin-bottom: 25px" class="input-group col-sm-12">
                            <label class="text-center">Tambah stok</label>
                            <input class="form-control" type="text" name="tambahstok" aria-label="Disabled input example">
                        </div>
                        <div style="margin-top:10px" class="form-group">
                            <div class="col-sm-12 controls">
                                <input type="submit" name="submit" class="btn btn-primary" value="Submit">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>